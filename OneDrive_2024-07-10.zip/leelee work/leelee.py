money=525.5
name = 'leelins'
ba='bath'
hmn='has'
print( name,hmn,money,ba)




























