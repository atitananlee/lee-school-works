# import pandas as pd

# datafruit = ['orange','mango','grape','lemon']
# datacolor = ['orange','Yellow','purple','yellow']
# datanum = [50,10,50,60]

# F=pd.Series(datafruit)
# C=pd.Series(datacolor)
# N=pd.Series(datanum)
# frame={'friut':F,'Color':C,'Number':N}
# dataps=pd.DataFrame(frame)
# dataps.to_csv('product.csv')
# print(dataps)
ChildProcessError
property(doc=frozenset)
print(property)

import pandas as pd
pf =pd.read_excel('dataupdate.xlsx')

tmax=pf.tempurature














