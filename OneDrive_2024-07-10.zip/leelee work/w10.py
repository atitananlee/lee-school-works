#Q04
print('hello welcome to Taotys department store')
hour=int(input('please enter your parking hours  '))
minute=int(input('please enter your parking minutes  '))
price=0
if minute % 60>=1:
 hour + 1
if hour==1 :
 print('free parking for 1 hours')
else:
  price = hour*30
print('the parking price is',price)
