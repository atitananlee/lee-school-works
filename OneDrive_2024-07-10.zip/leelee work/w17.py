def print_name(a,b,c):
    print(f'Your name is {a} {b}\n Your age is {c}')
name=str(input('enter your name  '))
surname=str(input('enter your surname '))
age=str(input('enter your age  '))
print_name(name,surname,age)


