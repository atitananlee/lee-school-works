import numpy as np
pricingfood= np.array([25,30,45])
dailykg=np.array([75,120,70,90,80])
dailykp=([80,90,100,70,50])
dailyskt=([50,45,70,65,50])
dailyamplate=np.
