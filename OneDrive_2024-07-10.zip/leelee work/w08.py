#Q1
width=int(input('please input width '))
length=int(input('please input length '))
if width<=0 or length <=0:
    print('please put in integer')
else:
    print('teh =',width*length)

