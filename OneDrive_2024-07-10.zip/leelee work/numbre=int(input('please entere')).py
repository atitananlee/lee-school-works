numbre=int(input('please entere'))
for i in range (0,13):
    print('---divide---\n')
    print (numbre*i=()\n)