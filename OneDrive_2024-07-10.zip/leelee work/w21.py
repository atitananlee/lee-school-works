s = '''想一个人一天
惊讶于我的改变
多复杂的考验
简单聊聊天
在你的左边
心温暖一点'''
f= open('想一个人一天.txt','w',encoding='utf-8')
f.write(s)
f.close
print(s)


