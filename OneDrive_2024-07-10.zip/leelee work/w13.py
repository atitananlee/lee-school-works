week = {'mon':' วันจันทร์ ','tue':' วันอังคาร ','wed':' วันพุธ ','turs':' วันพฤหัสบดี ','fri':' วันศุกร์ ','sat':' วันเสาร์ '}
for y in week.keys():
    print(y,end='')
    print('\nValues is ',end='')
    for y in week.values():
        print(y,end='')



