#Question1 
a=2
b=3
print(a,'x',b,'=','6')
#Question2
birthday=25
print('ฉันเกิดวันที่',birthday,'ธันวาคม')
#Questions3
a=3.50
print('เขามีเงินเยอะกว่าฉัน',a,'บาท')
#Questions4
a=5
print(f'ฉันได้กำไร {a}%')
                                         