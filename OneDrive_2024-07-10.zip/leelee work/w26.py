#ATM100,500,1000
money=int(input('กรุณาระบุจำนวนเงินที่ต้องการถอน : '))
money1=money//100
money_1=
้