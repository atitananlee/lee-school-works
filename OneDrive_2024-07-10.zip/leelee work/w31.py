import tkinter as tk
root= tk.Tk()
root.title('HOMEWORK GUI')
root.geometry('600x400+100+100')
for i in range(1,11):
    mylabel1 = tk.Label(text='leeling doesnt like ★★★★★★★★★★ to work',fg='midnightblue',font=50,bg='white')
    mylabel1.pack()
root.mainloop()0