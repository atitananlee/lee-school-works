berlist=[]
while len(berlist) < 5:
    input1=int((input('please input 5 integer  ')))
    berlist.append(input1)
berlist.sort
print(berlist[2])